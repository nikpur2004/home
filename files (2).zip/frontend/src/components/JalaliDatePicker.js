import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterJalali } from '@mui/x-date-pickers/AdapterJalali';
import dayjs from 'dayjs';

export default function JalaliDatePicker({ label, value, onChange }) {
  return (
    <LocalizationProvider dateAdapter={AdapterJalali}>
      <DatePicker
        label={label}
        value={value ? dayjs(value) : null}
        onChange={date => onChange(date ? date.format("YYYY-MM-DD") : "")}
        views={['year', 'month', 'day']}
        format="YYYY/MM/DD"
        slotProps={{
          textField: { fullWidth: true, margin: "dense" }
        }}
      />
    </LocalizationProvider>
  );
}