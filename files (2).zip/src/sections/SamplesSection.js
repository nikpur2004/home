import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
import JalaliDatePicker from "../components/JalaliDatePicker";
const api = "http://localhost:8000/api/samples";

export function SamplesSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({sample_id:"",encrypted_identity:"",barcode:"",period_id:"",center_id:"",status:"",operator_id:"",received_at:"",sent_at:""});
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r=>r.json()).then(setItems);
  }, [search, open]);
  const handleAdd = () => {
    setForm({sample_id: Date.now(), encrypted_identity:"", barcode:"", period_id:"", center_id:"", status:"", operator_id:"", received_at:"", sent_at:""});
    setEditId(null);
    setOpen(true);
  };
  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false); setEditId(null);});
    } else {
      fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false);});
    }
  };
  const handleDelete = (id) => { fetch(`${api}/${id}`,{method:"DELETE"}).then(()=>setSearch("")); };
  const handleEdit = (item) => { setForm(item); setEditId(item.sample_id); setOpen(true); };
  return (
    <Paper sx={{p:2}}>
      <Button variant="contained" sx={{mb:2}} onClick={handleAdd}>افزودن نمونه</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{mb:2,ml:2}} value={search} onChange={e=>setSearch(e.target.value)}/>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>هویت رمزنگاری‌شده</TableCell>
              <TableCell>بارکد</TableCell>
              <TableCell>ID دوره</TableCell>
              <TableCell>ID مرکز</TableCell>
              <TableCell>وضعیت</TableCell>
              <TableCell>اپراتور</TableCell>
              <TableCell>زمان دریافت</TableCell>
              <TableCell>زمان ارسال</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i=>(
              <TableRow key={i.sample_id}>
                <TableCell>{i.sample_id}</TableCell>
                <TableCell>{i.encrypted_identity}</TableCell>
                <TableCell>{i.barcode}</TableCell>
                <TableCell>{i.period_id}</TableCell>
                <TableCell>{i.center_id}</TableCell>
                <TableCell>{i.status}</TableCell>
                <TableCell>{i.operator_id}</TableCell>
                <TableCell>{i.received_at}</TableCell>
                <TableCell>{i.sent_at}</TableCell>
                <TableCell>
                  <Button size="small" onClick={()=>handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={()=>handleDelete(i.sample_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>{editId?"ویرایش نمونه":"افزودن نمونه"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.sample_id} disabled />
          <TextField label="هویت رمزنگاری‌شده" fullWidth margin="dense" value={form.encrypted_identity} onChange={e=>setForm({...form,encrypted_identity:e.target.value})}/>
          <TextField label="بارکد" fullWidth margin="dense" value={form.barcode} onChange={e=>setForm({...form,barcode:e.target.value})}/>
          <TextField label="ID دوره" fullWidth margin="dense" value={form.period_id} onChange={e=>setForm({...form,period_id:e.target.value})}/>
          <TextField label="ID مرکز" fullWidth margin="dense" value={form.center_id} onChange={e=>setForm({...form,center_id:e.target.value})}/>
          <TextField label="وضعیت" fullWidth margin="dense" value={form.status} onChange={e=>setForm({...form,status:e.target.value})}/>
          <TextField label="اپراتور" fullWidth margin="dense" value={form.operator_id} onChange={e=>setForm({...form,operator_id:e.target.value})}/>
          <JalaliDatePicker label="زمان دریافت" value={form.received_at} onChange={date=>setForm({...form,received_at:date})}/>
          <JalaliDatePicker label="زمان ارسال" value={form.sent_at} onChange={date=>setForm({...form,sent_at:date})}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId?"ذخیره":"ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}