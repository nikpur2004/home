import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
import JalaliDatePicker from "../components/JalaliDatePicker";
const api = "http://localhost:8000/api/logs";

export function LogsSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({log_id:"",action:"",user_id:"",sample_id:"",timestamp:"",description:""});
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r=>r.json()).then(setItems);
  }, [search, open]);
  const handleAdd = () => {
    setForm({log_id: Date.now(), action:"", user_id:"", sample_id:"", timestamp:"", description:""});
    setEditId(null);
    setOpen(true);
  };
  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false); setEditId(null);});
    } else {
      fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false);});
    }
  };
  const handleDelete = (id) => { fetch(`${api}/${id}`,{method:"DELETE"}).then(()=>setSearch("")); };
  const handleEdit = (item) => { setForm(item); setEditId(item.log_id); setOpen(true); };
  return (
    <Paper sx={{p:2}}>
      <Button variant="contained" sx={{mb:2}} onClick={handleAdd}>افزودن رخداد</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{mb:2,ml:2}} value={search} onChange={e=>setSearch(e.target.value)}/>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>عملیات</TableCell>
              <TableCell>ID کاربر</TableCell>
              <TableCell>ID نمونه</TableCell>
              <TableCell>زمان</TableCell>
              <TableCell>توضیحات</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i=>(
              <TableRow key={i.log_id}>
                <TableCell>{i.log_id}</TableCell>
                <TableCell>{i.action}</TableCell>
                <TableCell>{i.user_id}</TableCell>
                <TableCell>{i.sample_id}</TableCell>
                <TableCell>{i.timestamp}</TableCell>
                <TableCell>{i.description}</TableCell>
                <TableCell>
                  <Button size="small" onClick={()=>handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={()=>handleDelete(i.log_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>{editId?"ویرایش رخداد":"افزودن رخداد"}</DialogTitle>
        <DialogContent>
          <TextField label="ID رخداد" fullWidth margin="dense" value={form.log_id} disabled />
          <TextField label="عملیات" fullWidth margin="dense" value={form.action} onChange={e=>setForm({...form,action:e.target.value})}/>
          <TextField label="ID کاربر" fullWidth margin="dense" value={form.user_id} onChange={e=>setForm({...form,user_id:e.target.value})}/>
          <TextField label="ID نمونه" fullWidth margin="dense" value={form.sample_id} onChange={e=>setForm({...form,sample_id:e.target.value})}/>
          <JalaliDatePicker label="زمان" value={form.timestamp} onChange={date=>setForm({...form,timestamp:date})}/>
          <TextField label="توضیحات" fullWidth margin="dense" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId?"ذخیره":"ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}