import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
const api = "http://localhost:8000/api/quotas";

export function QuotasSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({quota_id:"",period_id:"",center_id:"",capacity:""});
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r=>r.json()).then(setItems);
  }, [search, open]);
  const handleAdd = () => {
    setForm({quota_id: Date.now(), period_id:"", center_id:"", capacity:""});
    setEditId(null);
    setOpen(true);
  };
  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false); setEditId(null);});
    } else {
      fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false);});
    }
  };
  const handleDelete = (id) => { fetch(`${api}/${id}`,{method:"DELETE"}).then(()=>setSearch("")); };
  const handleEdit = (item) => { setForm(item); setEditId(item.quota_id); setOpen(true); };
  return (
    <Paper sx={{p:2}}>
      <Button variant="contained" sx={{mb:2}} onClick={handleAdd}>افزودن سهمیه</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{mb:2,ml:2}} value={search} onChange={e=>setSearch(e.target.value)}/>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>ID دوره</TableCell>
              <TableCell>ID مرکز</TableCell>
              <TableCell>ظرفیت</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i=>(
              <TableRow key={i.quota_id}>
                <TableCell>{i.quota_id}</TableCell>
                <TableCell>{i.period_id}</TableCell>
                <TableCell>{i.center_id}</TableCell>
                <TableCell>{i.capacity}</TableCell>
                <TableCell>
                  <Button size="small" onClick={()=>handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={()=>handleDelete(i.quota_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>{editId?"ویرایش سهمیه":"افزودن سهمیه"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.quota_id} disabled />
          <TextField label="ID دوره" fullWidth margin="dense" value={form.period_id} onChange={e=>setForm({...form,period_id:e.target.value})}/>
          <TextField label="ID مرکز" fullWidth margin="dense" value={form.center_id} onChange={e=>setForm({...form,center_id:e.target.value})}/>
          <TextField label="ظرفیت" fullWidth margin="dense" value={form.capacity} onChange={e=>setForm({...form,capacity:e.target.value})}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId?"ذخیره":"ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}