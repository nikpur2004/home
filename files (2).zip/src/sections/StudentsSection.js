import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";

const api = "http://localhost:8000/api/students";

export function StudentsSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    student_id: "",
    name: "",
    national_code: "",
    mobile: "",
    father_name: ""
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r => r.json()).then(setItems);
  }, [search, open]);

  const handleAdd = () => {
    setForm({ student_id: Date.now(), name: "", national_code: "", mobile: "", father_name: "" });
    setEditId(null);
    setOpen(true);
  };

  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => {
        setOpen(false);
        setEditId(null);
      });
    } else {
      fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => setOpen(false));
    }
  };

  const handleDelete = id => {
    fetch(`${api}/${id}`, { method: "DELETE" }).then(() => setSearch(""));
  };

  const handleEdit = item => {
    setForm(item);
    setEditId(item.student_id);
    setOpen(true);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Button variant="contained" sx={{ mb: 2 }} onClick={handleAdd}>افزودن دانشجو</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{ mb: 2, ml: 2 }} value={search} onChange={e => setSearch(e.target.value)} />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام دانشجو</TableCell>
              <TableCell>کد ملی</TableCell>
              <TableCell>موبایل</TableCell>
              <TableCell>نام پدر</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i => (
              <TableRow key={i.student_id}>
                <TableCell>{i.student_id}</TableCell>
                <TableCell>{i.name}</TableCell>
                <TableCell>{i.national_code}</TableCell>
                <TableCell>{i.mobile}</TableCell>
                <TableCell>{i.father_name}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(i.student_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editId ? "ویرایش دانشجو" : "افزودن دانشجو"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.student_id} disabled />
          <TextField label="نام دانشجو" fullWidth margin="dense" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <TextField label="کد ملی" fullWidth margin="dense" value={form.national_code} onChange={e => setForm({ ...form, national_code: e.target.value })} />
          <TextField label="موبایل" fullWidth margin="dense" value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} />
          <TextField label="نام پدر" fullWidth margin="dense" value={form.father_name} onChange={e => setForm({ ...form, father_name: e.target.value })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId ? "ذخیره" : "ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}