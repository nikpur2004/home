import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";

const api = "http://localhost:8000/api/teachers";

export function TeachersSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    teacher_id: "",
    name: "",
    national_code: "",
    mobile: ""
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r => r.json()).then(setItems);
  }, [search, open]);

  const handleAdd = () => {
    setForm({ teacher_id: Date.now(), name: "", national_code: "", mobile: "" });
    setEditId(null);
    setOpen(true);
  };

  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => {
        setOpen(false);
        setEditId(null);
      });
    } else {
      fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => setOpen(false));
    }
  };

  const handleDelete = id => {
    fetch(`${api}/${id}`, { method: "DELETE" }).then(() => setSearch(""));
  };

  const handleEdit = item => {
    setForm(item);
    setEditId(item.teacher_id);
    setOpen(true);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Button variant="contained" sx={{ mb: 2 }} onClick={handleAdd}>افزودن استاد</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{ mb: 2, ml: 2 }} value={search} onChange={e => setSearch(e.target.value)} />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام استاد</TableCell>
              <TableCell>کد ملی</TableCell>
              <TableCell>موبایل</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i => (
              <TableRow key={i.teacher_id}>
                <TableCell>{i.teacher_id}</TableCell>
                <TableCell>{i.name}</TableCell>
                <TableCell>{i.national_code}</TableCell>
                <TableCell>{i.mobile}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(i.teacher_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editId ? "ویرایش استاد" : "افزودن استاد"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.teacher_id} disabled />
          <TextField label="نام استاد" fullWidth margin="dense" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <TextField label="کد ملی" fullWidth margin="dense" value={form.national_code} onChange={e => setForm({ ...form, national_code: e.target.value })} />
          <TextField label="موبایل" fullWidth margin="dense" value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId ? "ذخیره" : "ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}