import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
const api = "http://localhost:8000/api/centers";

export function CentersSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({center_id:"",center_name:"",center_type:""});
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r=>r.json()).then(setItems);
  }, [search, open]);
  const handleAdd = () => {
    setForm({center_id: Date.now(), center_name:"", center_type:""});
    setEditId(null);
    setOpen(true);
  };
  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false); setEditId(null);});
    } else {
      fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false);});
    }
  };
  const handleDelete = (id) => { fetch(`${api}/${id}`,{method:"DELETE"}).then(()=>setSearch("")); };
  const handleEdit = (item) => { setForm(item); setEditId(item.center_id); setOpen(true); };
  return (
    <Paper sx={{p:2}}>
      <Button variant="contained" sx={{mb:2}} onClick={handleAdd}>افزودن مرکز</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{mb:2,ml:2}} value={search} onChange={e=>setSearch(e.target.value)}/>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام مرکز</TableCell>
              <TableCell>نوع مرکز</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i=>(
              <TableRow key={i.center_id}>
                <TableCell>{i.center_id}</TableCell>
                <TableCell>{i.center_name}</TableCell>
                <TableCell>{i.center_type}</TableCell>
                <TableCell>
                  <Button size="small" onClick={()=>handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={()=>handleDelete(i.center_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>{editId?"ویرایش مرکز":"افزودن مرکز"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.center_id} disabled />
          <TextField label="نام مرکز" fullWidth margin="dense" value={form.center_name} onChange={e=>setForm({...form,center_name:e.target.value})}/>
          <TextField label="نوع مرکز" fullWidth margin="dense" value={form.center_type} onChange={e=>setForm({...form,center_type:e.target.value})}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId?"ذخیره":"ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}