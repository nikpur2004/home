import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";

const api = "http://localhost:8000/api/users";

export function UsersSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    user_id: "",
    name: "",
    username: "",
    password: "",
    role: ""
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r => r.json()).then(setItems);
  }, [search, open]);

  const handleAdd = () => {
    setForm({ user_id: Date.now(), name: "", username: "", password: "", role: "" });
    setEditId(null);
    setOpen(true);
  };

  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => {
        setOpen(false);
        setEditId(null);
      });
    } else {
      fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => setOpen(false));
    }
  };

  const handleDelete = id => {
    fetch(`${api}/${id}`, { method: "DELETE" }).then(() => setSearch(""));
  };

  const handleEdit = item => {
    setForm(item);
    setEditId(item.user_id);
    setOpen(true);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Button variant="contained" sx={{ mb: 2 }} onClick={handleAdd}>افزودن کاربر</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{ mb: 2, ml: 2 }} value={search} onChange={e => setSearch(e.target.value)} />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام</TableCell>
              <TableCell>نام کاربری</TableCell>
              <TableCell>نقش</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i => (
              <TableRow key={i.user_id}>
                <TableCell>{i.user_id}</TableCell>
                <TableCell>{i.name}</TableCell>
                <TableCell>{i.username}</TableCell>
                <TableCell>{i.role}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(i.user_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editId ? "ویرایش کاربر" : "افزودن کاربر"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.user_id} disabled />
          <TextField label="نام" fullWidth margin="dense" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <TextField label="نام کاربری" fullWidth margin="dense" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
          <TextField label="رمز عبور" fullWidth margin="dense" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <TextField label="نقش" fullWidth margin="dense" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId ? "ذخیره" : "ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}