import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
import JalaliDatePicker from "../components/JalaliDatePicker";

const api = "http://localhost:8000/api/periods";

export default function PeriodsSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    period_id: "",
    name: "",
    start_date: "",
    end_date: "",
    total_capacity: ""
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r => r.json()).then(setItems);
  }, [search, open]);

  const handleAdd = () => {
    setForm({ period_id: Date.now(), name: "", start_date: "", end_date: "", total_capacity: "" });
    setEditId(null);
    setOpen(true);
  };

  const handleSubmit = () => {
    const sendForm = { ...form };
    if (!sendForm.start_date) sendForm.start_date = "";
    if (!sendForm.end_date) sendForm.end_date = "";

    const method = editId ? "PUT" : "POST";
    const url = editId ? `${api}/${editId}` : api;

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sendForm)
    }).then(() => {
      setOpen(false);
      setEditId(null);
    });
  };

  const handleDelete = id => {
    fetch(`${api}/${id}`, { method: "DELETE" }).then(() => setSearch(""));
  };

  const handleEdit = item => {
    setForm(item);
    setEditId(item.period_id);
    setOpen(true);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Button variant="contained" sx={{ mb: 2 }} onClick={handleAdd}>افزودن دوره</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{ mb: 2, ml: 2 }} value={search} onChange={e => setSearch(e.target.value)} />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام دوره</TableCell>
              <TableCell>شروع</TableCell>
              <TableCell>پایان</TableCell>
              <TableCell>ظرفیت</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i => (
              <TableRow key={i.period_id}>
                <TableCell>{i.period_id}</TableCell>
                <TableCell>{i.name}</TableCell>
                <TableCell>{i.start_date}</TableCell>
                <TableCell>{i.end_date}</TableCell>
                <TableCell>{i.total_capacity}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(i.period_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editId ? "ویرایش دوره" : "افزودن دوره"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.period_id} disabled />
          <TextField label="نام دوره" fullWidth margin="dense" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <JalaliDatePicker
            label="تاریخ شروع"
            value={form.start_date}
            onChange={date => setForm({ ...form, start_date: date })}
          />
          <JalaliDatePicker
            label="تاریخ پایان"
            value={form.end_date}
            onChange={date => setForm({ ...form, end_date: date })}
          />
          <TextField label="ظرفیت" fullWidth margin="dense" value={form.total_capacity} onChange={e => setForm({ ...form, total_capacity: e.target.value })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId ? "ذخیره" : "ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}