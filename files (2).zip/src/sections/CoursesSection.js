import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";

const api = "http://localhost:8000/api/courses";

export function CoursesSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    course_id: "",
    name: "",
    code: "",
    units: ""
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r => r.json()).then(setItems);
  }, [search, open]);

  const handleAdd = () => {
    setForm({ course_id: Date.now(), name: "", code: "", units: "" });
    setEditId(null);
    setOpen(true);
  };

  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => {
        setOpen(false);
        setEditId(null);
      });
    } else {
      fetch(api, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }).then(() => setOpen(false));
    }
  };

  const handleDelete = id => {
    fetch(`${api}/${id}`, { method: "DELETE" }).then(() => setSearch(""));
  };

  const handleEdit = item => {
    setForm(item);
    setEditId(item.course_id);
    setOpen(true);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Button variant="contained" sx={{ mb: 2 }} onClick={handleAdd}>افزودن درس</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{ mb: 2, ml: 2 }} value={search} onChange={e => setSearch(e.target.value)} />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>نام درس</TableCell>
              <TableCell>کد درس</TableCell>
              <TableCell>تعداد واحد</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i => (
              <TableRow key={i.course_id}>
                <TableCell>{i.course_id}</TableCell>
                <TableCell>{i.name}</TableCell>
                <TableCell>{i.code}</TableCell>
                <TableCell>{i.units}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(i.course_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editId ? "ویرایش درس" : "افزودن درس"}</DialogTitle>
        <DialogContent>
          <TextField label="ID" fullWidth margin="dense" value={form.course_id} disabled />
          <TextField label="نام درس" fullWidth margin="dense" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <TextField label="کد درس" fullWidth margin="dense" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} />
          <TextField label="تعداد واحد" fullWidth margin="dense" value={form.units} onChange={e => setForm({ ...form, units: e.target.value })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId ? "ذخیره" : "ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}