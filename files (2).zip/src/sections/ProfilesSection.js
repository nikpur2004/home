import React, { useEffect, useState } from "react";
import {
  Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Button, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
import JalaliDatePicker from "../components/JalaliDatePicker";
const api = "http://localhost:8000/api/profiles";

export function ProfilesSection() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({profile_id:"",sample_id:"",encrypted_data:"",analyzed_at:""});
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetch(api + (search ? `?q=${search}` : "")).then(r=>r.json()).then(setItems);
  }, [search, open]);
  const handleAdd = () => {
    setForm({profile_id: Date.now(), sample_id:"", encrypted_data:"", analyzed_at:""});
    setEditId(null);
    setOpen(true);
  };
  const handleSubmit = () => {
    if (editId) {
      fetch(`${api}/${editId}`, {method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false); setEditId(null);});
    } else {
      fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}).then(()=>{setOpen(false);});
    }
  };
  const handleDelete = (id) => { fetch(`${api}/${id}`,{method:"DELETE"}).then(()=>setSearch("")); };
  const handleEdit = (item) => { setForm(item); setEditId(item.profile_id); setOpen(true); };
  return (
    <Paper sx={{p:2}}>
      <Button variant="contained" sx={{mb:2}} onClick={handleAdd}>افزودن تحلیل</Button>
      <TextField label="جستجو..." variant="outlined" size="small" sx={{mb:2,ml:2}} value={search} onChange={e=>setSearch(e.target.value)}/>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>کد</TableCell>
              <TableCell>ID نمونه</TableCell>
              <TableCell>داده رمزنگاری‌شده</TableCell>
              <TableCell>تاریخ تحلیل</TableCell>
              <TableCell>عملیات</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map(i=>(
              <TableRow key={i.profile_id}>
                <TableCell>{i.profile_id}</TableCell>
                <TableCell>{i.sample_id}</TableCell>
                <TableCell>{i.encrypted_data}</TableCell>
                <TableCell>{i.analyzed_at}</TableCell>
                <TableCell>
                  <Button size="small" onClick={()=>handleEdit(i)}>ویرایش</Button>
                  <Button size="small" color="error" onClick={()=>handleDelete(i.profile_id)}>حذف</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={()=>setOpen(false)}>
        <DialogTitle>{editId?"ویرایش تحلیل":"افزودن تحلیل"}</DialogTitle>
        <DialogContent>
          <TextField label="ID پروفایل" fullWidth margin="dense" value={form.profile_id} disabled />
          <TextField label="ID نمونه" fullWidth margin="dense" value={form.sample_id} onChange={e=>setForm({...form,sample_id:e.target.value})}/>
          <TextField label="داده رمزنگاری‌شده" fullWidth margin="dense" value={form.encrypted_data} onChange={e=>setForm({...form,encrypted_data:e.target.value})}/>
          <JalaliDatePicker label="تاریخ تحلیل" value={form.analyzed_at} onChange={date=>setForm({...form,analyzed_at:date})}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpen(false)}>لغو</Button>
          <Button onClick={handleSubmit} variant="contained">{editId?"ذخیره":"ثبت"}</Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
}