import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import jalali from 'dayjs-jalali';
import 'dayjs/locale/fa';

dayjs.extend(jalali);
dayjs.locale('fa');

export default function JalaliDatePicker({ label, value, onChange }) {
  let dateValue = null;

  // فقط اگر رشته جلالی معتبر باشد، تبدیل کن
  if (
    typeof value === "string" &&
    /^\d{4}\/\d{2}\/\d{2}$/.test(value)
  ) {
    dateValue = dayjs(value, "jYYYY/jMM/jDD");
    // اگر تاریخ معتبر نیست یا سال جلالی غیرمنطقی است، null شود
    if (!dateValue.isValid() || dateValue.jYear() < 1200) dateValue = null;
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="fa">
      <DatePicker
        label={label}
        value={dateValue}
        onChange={date => onChange(date ? date.format("jYYYY/jMM/jDD") : "")}
        views={['year', 'month', 'day']}
        format="jYYYY/jMM/jDD"
        slotProps={{
          textField: { fullWidth: true, margin: "dense" }
        }}
      />
    </LocalizationProvider>
  );
}